library(testthat)
library(msentropy)

test_check("msentropy")



